# Latein lernen — Vokabeltrainer

Eine kleine, komplett clientseitige (reines HTML/CSS/JavaScript, kein Server nötig)
Lern-Website für deinen lateinischen Wortschatz, mit:

- **Karteikarten** mit Lektionsauswahl. Wörter aus Lektionen, bei denen du viele
  Fehler machst, kommen automatisch häufiger dran.
- **Suche** nach Vokabelformen (z. B. `servi`) mit allen möglichen grammatischen
  Deutungen, ähnlich wie bei latein.me — aber nur mit deinem eigenen Wortschatz.
- **Formentrainer** (Deklination/Konjugation) mit zwei Modi: Auswahlfelder
  (Modus 1) oder Eintippen (Modus 2), filterbar nach Lektion, Wortart und
  bereits bekannten Fällen/Zeitformen.
- **Streak** mit Tagesziel und Pausentagen.
- **Einstellungen**: Dark Mode, Schriftgröße, Fortschritt zurücksetzen.

Der gesamte Fortschritt (Karteikarten-Statistik, Streak, Einstellungen) wird
**nur lokal im Browser** gespeichert (`localStorage`) — es gibt keinen Server,
kein Konto, keine Analyse-Tools. Auf einem anderen Gerät fängst du bei null an.

## 1. Dateistruktur

```
latein-lernen/
├── index.html            Einstiegsseite (öffnet Karteikarten)
├── css/
│   └── style.css          alle Styles inkl. Dark Mode
├── js/
│   ├── morphology.js       Deklinations-/Konjugations-Engine (das "Gehirn")
│   ├── storage.js          localStorage-Zugriff (Fortschritt, Einstellungen)
│   ├── data.js             lädt data/vocab.json, Lektions-/Wortart-Filter
│   ├── lexutil.js          baut die "servus, -ī m."-Kurzschreibweise
│   ├── streak.js           Streak-Logik (Tagesziel, Pausentage)
│   ├── flashcards.js       Karteikarten-Feature
│   ├── search.js           Such-Feature inkl. Formen-Index
│   ├── forms.js             Formentrainer (Modus 1 & 2)
│   └── app.js               Navigation, Streak-/Einstellungen-Ansicht, Start
├── data/
│   └── vocab.json          dein geparster Wortschatz (wird von der Website geladen)
└── tools/
    ├── vocab_raw.txt        Rohtext-Wortschatzliste (deine ursprüngliche Liste)
    ├── parse_vocab.py       Skript, das vocab_raw.txt -> vocab.json umwandelt
    └── test_morphology.js   Node-Tests für die Formen-Engine (optional)
```

## 2. Auf GitHub veröffentlichen (GitHub Pages)

1. Erstelle auf [github.com](https://github.com) ein neues Repository, z. B. `latein-lernen`.
2. Lade **den gesamten Inhalt dieses Ordners** (nicht den Ordner selbst, sondern
   `index.html`, `css/`, `js/`, `data/`, `tools/`) in das Repository hoch —
   entweder per Drag & Drop auf der GitHub-Webseite ("Add file" → "Upload files")
   oder per Git:
   ```bash
   git init
   git add .
   git commit -m "Erste Version"
   git branch -M main
   git remote add origin https://github.com/DEIN-NUTZERNAME/latein-lernen.git
   git push -u origin main
   ```
3. Im Repository: **Settings → Pages**. Bei "Source" wähle den Branch `main`
   und Ordner `/ (root)`. Speichern.
4. Nach ein bis zwei Minuten ist die Seite unter
   `https://DEIN-NUTZERNAME.github.io/latein-lernen/` erreichbar.

Das war's — es gibt keinen Build-Schritt, keine Abhängigkeiten, nichts zu
installieren. GitHub Pages liefert einfach die Dateien so aus, wie sie sind.

## 3. Lokal testen (bevor du hochlädst)

Da die Seite `fetch()` benutzt, um `data/vocab.json` zu laden, funktioniert ein
**Doppelklick auf `index.html`** in manchen Browsern nicht (Sicherheitsbeschränkung
bei `file://`-Seiten). Starte stattdessen im Ordner einen kleinen lokalen Server:

```bash
cd latein-lernen
python3 -m http.server 8000
```

und öffne dann `http://localhost:8000` im Browser. Node-Nutzer können
alternativ `npx serve` verwenden.

## 4. Später Unterlektionen ergänzen (z. B. "1.1" statt "1")

Deine aktuelle Liste hat nur Hauptlektionen (1, 2, 3, …). Wenn du mir die
Unterlektionen schickst, kann ich `tools/vocab_raw.txt` aktualisieren und
`tools/parse_vocab.py` neu laufen lassen, um `data/vocab.json` zu aktualisieren.

Falls du es selbst machen möchtest (Python 3 nötig, ohne Zusatzpakete):

1. Öffne `tools/vocab_raw.txt` und ändere die Lektionsangabe am Zeilenende,
   z. B. `servus Sklave, Diener - 1` → `servus Sklave, Diener - 1.1`.
   Mehrere Lektionen weiterhin komma-getrennt: `... - 1.1, 3.2`.
2. Führe im Ordner `tools/` aus:
   ```bash
   python3 parse_vocab.py
   ```
3. Das überschreibt `data/vocab.json`. Lade die aktualisierte Datei zusammen
   mit `vocab_raw.txt` wieder auf GitHub hoch (einfach erneut committen/pushen
   bzw. die Dateien in der GitHub-Weboberfläche ersetzen).

Die Lektions-Auswahl in Karteikarten und Formentrainer gruppiert automatisch
nach Hauptlektion (z. B. "6" für "6.1"/"6.2"), du musst an der Website selbst
nichts anpassen.

## 5. Wie die Formen-Engine funktioniert (kurz)

`js/morphology.js` dekliniert Substantive/Adjektive/Pronomen und konjugiert
Verben **automatisch** aus den Angaben in `vocab.json` (Genitiv, Prinzipalformen
usw.) nach den regelmäßigen lateinischen Endungsmustern, inklusive:

- 1.–5. Deklination, i-Stämme (Gen. Pl. auf `-ium`), Pluralia tantum
  (`arma, castra, …`), sowie die "echten" Unregelmäßigkeiten `domus`, `vīs`, `Iuppiter`.
- 1.–4. Konjugation inkl. i-Stämmen der 3. Konjugation (`capiō`-Typ),
  Deponentien, und die unregelmäßigen Verben `esse`, `posse`, `velle`, `nōlle`,
  `ferre`, `īre`, `fierī`, `dare` — inklusive ihrer Komposita
  (`abesse`, `afferre`, `abīre`, …).

**Grenzen, die bewusst so gewählt sind** (lieber ehrlich "kann ich nicht
anzeigen" als eine falsche Form zu erfinden):

- Wenn im Wörterbuch nur Infinitiv + Präsens angegeben sind (typisch für
  frühe Lektionen), kann kein Perfekt/Partizip erzeugt werden — dafür fehlen
  die nötigen Stammformen. Diese Verben tauchen im Formentrainer dann nur mit
  ihren Präsens-Formen auf.
- Das periphrastische Passiv-Perfektsystem (`amātus sum/eram/erō …`) wird
  nicht generiert, da es vom Subjekt abhängige Endungen (Genus/Numerus des
  Partizips) hätte, die ohne Kontext willkürlich wären.
- Ein paar sehr seltene Einzelfälle in `vocab_raw.txt` sind uneindeutig
  formuliert und wurden nach bestem Ermessen als Wortart eingeordnet (z. B.
  `tellūs`, wo Wortart und Übersetzung im Originaltext nicht ganz zusammenzupassen
  scheinen) — das kannst du bei Bedarf direkt in `vocab_raw.txt` korrigieren.

Bei Fragen oder wenn du weitere Lektionen/Korrekturen schicken willst, kannst
du dich einfach wieder an mich (Claude) wenden.
